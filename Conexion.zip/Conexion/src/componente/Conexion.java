package componente;
import java.sql.*;
public class Conexion {
    Connection conexion;
    public Conexion(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            String bd = "jdbc:mysql://localhost:3306/GestorTareas";
            String usuario = "root";
            String clave = "qwerty";
            conexion = DriverManager.getConnection(bd, usuario, clave);
        }catch(Exception e){
            System.out.println("Error conectarse con la base de datos");
        }
    }
    public Conexion(String bd, String usuario, String clave){
        try{
            Class.forName("org.hsqldb.jdbc.JDBCDriver");
            conexion = DriverManager.getConnection(bd, usuario, clave);
        }catch(Exception e){
            System.out.println("Error conectarse con la base de datos");
        }
    }
    public Connection getConexion(){
        return this.conexion;
    }
}
