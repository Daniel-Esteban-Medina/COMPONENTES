package prueba;
import java.sql.*;
import componente.Conexion;

public class Prueba {
    static Connection con = null; 
    static Statement st = null; 
    static ResultSet rs = null;
    public static void main(String[] args){
        Conexion c = new Conexion();
        con = c.getConexion();
       try {
           st = con.createStatement();
           rs = st.executeQuery("SELECT Codigo, Titulo FROM Tareas");
           while (rs.next()) {
               int id = rs.getInt("Codigo");
               String titulo = rs.getString("titulo");
               System.out.println(id+"\n"+titulo);
           }
           con.close();
           st.close();
           rs.close();
           
       }catch(Exception e){
           e.printStackTrace();
       }
    }
}
