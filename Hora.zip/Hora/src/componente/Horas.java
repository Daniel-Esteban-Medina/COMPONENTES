package componente;
import componente.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
public class Horas extends javax.swing.JPanel {
    private int horas = 1;
    private Timer timer;
    private boolean incrementar;
    public Horas() {
        initComponents();
        jLabel1.setText("0"+String.valueOf(horas));
        timer = new Timer(170, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (incrementar) {
                    incrementar();
                } else {
                    decrementar();
                }
            }
        });
        jButtonMas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                incrementar = true; // Cuando presionas el botón, incrementar se vuelve true (incrementar)
                timer.start(); // Inicia el Timer
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                timer.stop(); // Detiene el Timer al soltar el botón
            }
        });
        jButtonMenos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                incrementar = false; // Cuando presionas el botón, incrementar se vuelve false (decrementar)
                timer.start(); // Inicia el Timer
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                timer.stop(); // Detiene el Timer al soltar el botón
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jButtonMas = new javax.swing.JButton();
        jButtonMenos = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        jLabel2.setText("jLabel2");

        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButtonMas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/componente/flechaAriba (1).png"))); // NOI18N
        jButtonMas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMasActionPerformed(evt);
            }
        });
        add(jButtonMas, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, 40, 30));

        jButtonMenos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/componente/flechaAbajo (1).png"))); // NOI18N
        jButtonMenos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMenosActionPerformed(evt);
            }
        });
        add(jButtonMenos, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 50, 40, 30));

        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("12");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 80, 60));

        jLabel3.setBackground(new java.awt.Color(179, 195, 196));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("HORAS");
        jLabel3.setOpaque(true);
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 120, 20));
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonMasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMasActionPerformed
        incrementar();
    }//GEN-LAST:event_jButtonMasActionPerformed

    private void jButtonMenosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMenosActionPerformed
        decrementar();
    }//GEN-LAST:event_jButtonMenosActionPerformed
    public int getHoras() {
        return horas;
    }
    public void setHoras(int horas) {
        try{
            boolean formatoAceptable = true;
            if(horas < 1){
                System.out.println("No se puede poner 0 o numeros negativos como hora");     
                formatoAceptable = false;
            }
            if(horas > 24){
                System.out.println("No se puede poner mas de 24, que son las que tiene el dia");
                formatoAceptable = false;
            }
            if(formatoAceptable == true){
                this.horas = horas;
                if(horas == 24){
                    jLabel1.setText("00");
                }else{
                    if (String.valueOf(horas).length() == 1) {
                        jLabel1.setText("0" + String.valueOf(horas));
                    } else {
                        jLabel1.setText(String.valueOf(horas));
                    }
                }
            }
        }catch(NumberFormatException e){
            System.out.println("El formato de hora introducido no es valido. Debe ser un numero entero, un INT");
        }
    }
    public String getStringHoras(){        
        String stringHoras = "";        
        if(horas == 24){
            stringHoras = "00";
        }else{
            stringHoras = String.valueOf(horas);
            if (stringHoras.length() == 1) {
                stringHoras = "0" + stringHoras;
            }
        }
        return stringHoras;
    }
    private void incrementar(){
        horas = horas + 1;
        if(horas > 24){
            horas = 1;
        }
        if(horas == 24){
            jLabel1.setText("00");
        }else{
            if (String.valueOf(horas).length() == 1) {
                jLabel1.setText("0" + String.valueOf(horas));
            } else {
                jLabel1.setText(String.valueOf(horas));
            }
        }
    }
    private void decrementar(){
        horas = horas - 1;
        if(horas < 1){
            horas = 24;
            jLabel1.setText("00");
        }else{
            if (String.valueOf(horas).length() == 1) {
                jLabel1.setText("0" + String.valueOf(horas));
            } else {
                jLabel1.setText(String.valueOf(horas));
            }
        }
    }
    public void setEditable(boolean editable){
        jButtonMas.setEnabled(editable);
        jButtonMenos.setEnabled(editable);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonMas;
    private javax.swing.JButton jButtonMenos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}