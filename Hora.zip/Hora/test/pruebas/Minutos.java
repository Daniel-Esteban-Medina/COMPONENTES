package pruebas;
import componente.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
public class Minutos extends javax.swing.JPanel {
    private int minutos = 0;
    private Timer timer;
    private boolean incrementar;
    public Minutos() {
        initComponents();
        jLabel1.setText("0"+String.valueOf(minutos));
        timer = new Timer(150, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (incrementar) {
                    incrementar();
                } else {
                    decrementar();
                }
            }
        });
        jButtonMas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                incrementar = true; // Cuando presionas el botón, incrementar se vuelve true (incrementar)
                timer.start(); // Inicia el Timer
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                timer.stop(); // Detiene el Timer al soltar el botón
            }
        });
        jButtonMenos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                incrementar = false; // Cuando presionas el botón, incrementar se vuelve false (decrementar)
                timer.start(); // Inicia el Timer
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                timer.stop(); // Detiene el Timer al soltar el botón
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButtonMas = new javax.swing.JButton();
        jButtonMenos = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButtonMas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pruebas/flechaAriba (1).png"))); // NOI18N
        jButtonMas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMasActionPerformed(evt);
            }
        });
        add(jButtonMas, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, 40, 30));

        jButtonMenos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pruebas/flechaAbajo (1).png"))); // NOI18N
        jButtonMenos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMenosActionPerformed(evt);
            }
        });
        add(jButtonMenos, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 50, 40, 30));

        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("60");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 80, 60));

        jLabel3.setBackground(new java.awt.Color(179, 195, 196));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("MINUTOS");
        jLabel3.setOpaque(true);
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 120, 20));
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonMasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMasActionPerformed
        incrementar();
    }//GEN-LAST:event_jButtonMasActionPerformed

    private void jButtonMenosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMenosActionPerformed
        decrementar();
    }//GEN-LAST:event_jButtonMenosActionPerformed
    public int getMinutos() {
        return minutos;
    }
    public void setMinutos(int minutos) {
        try{
            boolean formatoAceptable = true;
            if(minutos < 0){
                System.out.println("No se puede poner numeros negativos como minutos");     
                formatoAceptable = false;
            }
            if(minutos > 59){
                System.out.println("No se puede poner mas de 59 minutos");
                formatoAceptable = false;
            }
            if(formatoAceptable == true){
                this.minutos = minutos;               
                if (String.valueOf(minutos).length() == 1) {
                    jLabel1.setText("0" + String.valueOf(minutos));
                } else {
                    jLabel1.setText(String.valueOf(minutos));
                }                
            }
        }catch(NumberFormatException e){
            System.out.println("El formato de minutos introducido no es valido. Debe ser un numero entero, un INT");
        }
    }
    public String getStringMinutos(){        
        String stringMinutos = "";        
            stringMinutos = String.valueOf(minutos);
            if (stringMinutos.length() == 1) {
                stringMinutos = "0" + stringMinutos;
            }
        return stringMinutos;
    }
    private void incrementar(){
        minutos = minutos + 1;
        if(minutos >= 60){
            minutos = 0;
        }
        if (String.valueOf(minutos).length() == 1) {
            jLabel1.setText("0" + String.valueOf(minutos));
        } else {
            jLabel1.setText(String.valueOf(minutos));
        }
    }
    private void decrementar(){
        minutos = minutos - 1;
        if(minutos < 0){
            minutos = 59;
        }
        if (String.valueOf(minutos).length() == 1) {
            jLabel1.setText("0" + String.valueOf(minutos));
        } else {
            jLabel1.setText(String.valueOf(minutos));
        }
    }
    public void setEditable(boolean editable){
        jButtonMas.setEnabled(editable);
        jButtonMenos.setEnabled(editable);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonMas;
    private javax.swing.JButton jButtonMenos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
