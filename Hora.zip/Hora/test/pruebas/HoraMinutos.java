package pruebas;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JPopupMenu;

public class HoraMinutos extends javax.swing.JPanel {  
    private Horas h = new Horas();
    private Minutos m = new Minutos();
    public HoraMinutos() {
        initComponents();
        this.add(h);
        this.add(m);
    }
    @SuppressWarnings("unchecked")
    public String getHorasMinutos(){
        String horasMinutos = h.getStringHoras()+":"+m.getStringMinutos();
        return horasMinutos;
    }
    public int getHoras(){
       return h.getHoras();
    }
    public int getMinutos(){
        return m.getMinutos();
    }
    public void setHoras(int horas){
        h.setHoras(horas);
    }
    public void setMinutos(int minutos){
        m.setMinutos(minutos);
    }
    public void setHorasMinutos(int horas, int minutos){
        h.setHoras(horas);
        m.setMinutos(minutos);
    }
    public void setEditable(boolean editable){
        h.setEditable(editable);
        m.setEditable(editable);
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        setLayout(new java.awt.GridBagLayout());
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}