package componente;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Calendar;
import java.util.Date;
import org.jdesktop.swingx.JXDatePicker;

public class Fecha extends javax.swing.JPanel {
    private String dia = "";
    private String mes = "";
    private String ayo = "";
    private String fechaEsp = "";
    private String dateTime = "";
    // Crear un objeto Calendar
    Calendar calendario = Calendar.getInstance();    
    Date fecha; // Declarar la variable Date

    public Fecha() {
        initComponents();
        jXDatePicker1.getEditor().setEditable(false);
        jXDatePicker1.getEditor().setText("Seleccione fecha");
        jXDatePicker1.addPropertyChangeListener("date", new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                String fecha = jXDatePicker1.getDate().toString();
                String[] parts = fecha.split(" ");
                mes = parts[1];
                ponerNumMes(mes);
                dia = parts[2];  
                ayo = parts[5];        
                fechaEsp = dia+"/"+mes+"/"+ayo;
                // YYYY-MM-DD
                dateTime = ayo+"-"+mes+"-"+dia;
                jXDatePicker1.getEditor().setText(fechaEsp); // Cambiar el texto del editor
            }
        });
    }
    public void ponerNumMes(String mes){
        switch(mes){
            case "Jan":
                this.mes = "01";
            break;
            case "Feb":
                this.mes = "02";
            break;
            case "Mar":
                this.mes = "03";
            break;
            case "Apr":
                this.mes = "04";
            break;
            case "May":
                this.mes = "05";
            break;
            case "Jun":
                this.mes = "06";
            break;
            case "Jul":
                this.mes = "07";
            break;
            case "Aug":
                this.mes = "08";
            break;
            case "Sep":
                this.mes = "09";
            break;
            case "Oct":
                this.mes = "10";
            break;
            case "Nov":
                this.mes = "11";
            break;
            case "Dec":
                this.mes = "12";
            break;
        }
    }
    public void ponerFecha(int dia, int mes, int ayo) {
        boolean formatoAdecuado = true;
        if(dia < 1 || dia > 31){
            System.out.println("El dia no puede ser menos que 1 o mas que 31");
            formatoAdecuado = false;
        }
        if(mes < 1 || mes > 12){
            System.out.println("El mes no puede ser menos que 1 o mas que 12");
            formatoAdecuado = false;
        }
        if(ayo < 1000 || ayo > 9999){
            System.out.println("El año no puede ser menos que 1000 o mas que 9999");
            formatoAdecuado = false;
        }
        if(formatoAdecuado == true){
            calendario.set(ayo, mes - 1, dia); // Establecer la fecha en el Calendar
            fecha = calendario.getTime(); // Obtener el objeto Date del Calendar
            jXDatePicker1.setDate(fecha); // Establecer la fecha en el JXDatePicker
        }
    }
    public String obtenerDia() {
        return dia;
    }

    public void ponerDia(String dia) {
        this.dia = dia;
    }

    public String obtenerMes() {
        return mes;
    }

    public void ponerMes(String mes) {
        this.mes = mes;
    }

    public String obtenerAyo() {
        return ayo;
    }

    public void ponerAyo(String ayo) {
        this.ayo = ayo;
    }

    public String obtenerFechaEsp() {
        return fechaEsp;
    }

    public void ponerFechaEsp(String fechaEsp) {
        this.fechaEsp = fechaEsp;
    }

    public String obtenerDateTime() {
        return dateTime;
    }

    public void ponerDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public Calendar obtenerCalendario() {
        return calendario;
    }

    public void ponerCalendario(Calendar calendario) {
        this.calendario = calendario;
    }

    public Date obtenerFecha() {
        return fecha;
    }

    public void ponerFecha(Date fecha) {
        this.fecha = fecha;
    }

    public JXDatePicker obtenerjXDatePicker1() {
        return jXDatePicker1;
    }

    public void ponerjXDatePicker1(JXDatePicker jXDatePicker1) {
        this.jXDatePicker1 = jXDatePicker1;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jXDatePicker1 = new org.jdesktop.swingx.JXDatePicker();

        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        setLayout(new java.awt.GridLayout());
        add(jXDatePicker1);
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private org.jdesktop.swingx.JXDatePicker jXDatePicker1;
    // End of variables declaration//GEN-END:variables
}
