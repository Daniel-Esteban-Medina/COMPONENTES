package pruebas;

import componente.AdjuntosSubida;

public class VentanaSubida extends javax.swing.JFrame {
    
    public VentanaSubida() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        adjuntosSubida1 = new componente.AdjuntosSubida();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.GridLayout(1, 0));
        getContentPane().add(adjuntosSubida1);

        jButton1.setText("OBTENER LINK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String link = this.adjuntosSubida1.getLinkArchivo();
        if(link != ""){
            System.out.println("Link del archivo subido: " + link);
        }
    }//GEN-LAST:event_jButton1ActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaSubida().setVisible(true);               
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private componente.AdjuntosSubida adjuntosSubida1;
    private javax.swing.JButton jButton1;
    // End of variables declaration//GEN-END:variables
}
