package componente;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Paths;
public class AdjuntosBajada extends javax.swing.JPanel {
    private String downloadUrl;
    public AdjuntosBajada() {
        initComponents();
        jButtonAdjuntos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Descargar el archivo
                    if (downloadUrl != null && !downloadUrl.isEmpty()) {
                        bajarArchivo(downloadUrl);
                    } else {
                        JOptionPane.showMessageDialog(
                            AdjuntosBajada.this,
                            "La URL de descarga no está configurada.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE
                        );
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(
                        AdjuntosBajada.this,
                        "Error: " + ex.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                    );
                    ex.printStackTrace();
                }
            }
        });
    }
    @SuppressWarnings("unchecked")
    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }
    private void bajarArchivo(String fileUrl) throws Exception {
    URL url = new URL(fileUrl);
    // Abrir conexión HTTP
    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
    connection.setRequestMethod("GET");
    connection.setDoInput(true);
    // Obtener el código de respuesta
    int responseCode = connection.getResponseCode();
    if (responseCode == HttpURLConnection.HTTP_OK) {
        String contentDisposition = connection.getHeaderField("Content-Disposition");
        String filename = "descargado";
        if (contentDisposition != null && contentDisposition.contains("filename=")) {
            filename = contentDisposition.split("filename=")[1].replace("\"", "");
        }
        // Obtener la carpeta de descargas del sistema
        String downloadsFolder = FileUtil.obtenerCarpetaDescargas();
        // Crear la ruta completa donde se guardará el archivo
        String filePath = Paths.get(downloadsFolder, filename).toString();
        // Guardar el archivo en la carpeta de descargas
        try (InputStream inputStream = connection.getInputStream();
             FileOutputStream fileOutputStream = new FileOutputStream(filePath)) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                fileOutputStream.write(buffer, 0, bytesRead);
            }
        }
        // mensaje de éxito
        JOptionPane.showMessageDialog(
            this,
            "Archivo descargado exitosamente en " + filePath,
            "Éxito",
            JOptionPane.INFORMATION_MESSAGE
        );

    } else {
        throw new Exception("Error al descargar el archivo. Código de respuesta: " + responseCode);
    }    
}
    public String getDownloadUrl(){
        return downloadUrl;
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButtonAdjuntos = new javax.swing.JButton();

        jButtonAdjuntos.setBackground(new java.awt.Color(221, 236, 238));
        jButtonAdjuntos.setFont(new java.awt.Font("Malgun Gothic", 1, 18)); // NOI18N
        jButtonAdjuntos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/componente/pngwing.com.png"))); // NOI18N
        jButtonAdjuntos.setText("Adjuntos");
        jButtonAdjuntos.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButtonAdjuntos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAdjuntosActionPerformed(evt);
            }
        });
        add(jButtonAdjuntos);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAdjuntosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAdjuntosActionPerformed
        
    }//GEN-LAST:event_jButtonAdjuntosActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAdjuntos;
    // End of variables declaration//GEN-END:variables
}
