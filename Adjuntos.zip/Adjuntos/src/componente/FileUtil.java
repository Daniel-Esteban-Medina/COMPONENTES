package componente;

import java.nio.file.Paths;

public class FileUtil {
    // Obtener la ruta de la carpeta de descargas
    public static String obtenerCarpetaDescargas() {
        String userHome = System.getProperty("user.home");
        if (System.getProperty("os.name").toLowerCase().contains("win")) {
            // Windows
            return Paths.get(userHome, "Downloads").toString();
        } else if (System.getProperty("os.name").toLowerCase().contains("mac")) {
            // macOS
            return Paths.get(userHome, "Downloads").toString();
        } else {
            // Linux
            return Paths.get(userHome, "Downloads").toString();
        }
    }
}
