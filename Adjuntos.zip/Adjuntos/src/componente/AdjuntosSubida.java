package componente;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import javax.swing.filechooser.FileNameExtensionFilter;

public class AdjuntosSubida extends javax.swing.JPanel {
    private String uploadUrl = "https://file.io";
    private String linkArchivo = "";

    public AdjuntosSubida() {
        initComponents();
        jButtonAdjuntos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Abrir el explorador de archivos y subir el archivo
                    String filePath = seleccionarArchivo();
                    if (filePath != null) {
                        linkArchivo = subirArchivo(filePath);
                        // Mostrar el enlace en un mensaje
                        JOptionPane.showMessageDialog(AdjuntosSubida.this,
                            "Archivo subido exitosamente. Link: " + linkArchivo,
                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(
                        AdjuntosSubida.this,
                        "Error: " + ex.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                    );
                    ex.printStackTrace();
                }
            }
        });
    }

    @SuppressWarnings("unchecked")
    public void setUploadUrl(String uploadUrl) {
        this.uploadUrl = uploadUrl;
    }

    private String seleccionarArchivo() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter("Todos los Archivos", "*"));
        int resultado = fileChooser.showOpenDialog(this);
        if (resultado == JFileChooser.APPROVE_OPTION) {
            File archivoSeleccionado = fileChooser.getSelectedFile();
            return archivoSeleccionado.getAbsolutePath();
        } else {
            System.out.println("No se seleccionó ningún archivo.");
            return null;
        }
    }
    // Sube el archivo y guarda el link en una variable.
    private String subirArchivo(String filePath) throws Exception {
        if (uploadUrl == null || uploadUrl.isEmpty()) {
            throw new Exception("La URL de subida no está configurada.");
        }
        File file = new File(filePath);
        if (!file.exists()) {
            throw new Exception("El archivo no existe: " + filePath);
        }
        // Abrir conexión HTTP
        URL url = new URL(uploadUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setDoOutput(true);
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW");
        try (OutputStream outputStream = connection.getOutputStream()) {
            String boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW";
            String lineEnd = "\r\n";
            String twoHyphens = "--";
            outputStream.write((twoHyphens + boundary + lineEnd).getBytes(StandardCharsets.UTF_8));
            outputStream.write(("Content-Disposition: form-data; name=\"file\"; filename=\"" + file.getName() + "\"" + lineEnd).getBytes(StandardCharsets.UTF_8));
            outputStream.write(("Content-Type: application/octet-stream" + lineEnd).getBytes(StandardCharsets.UTF_8));
            outputStream.write(lineEnd.getBytes(StandardCharsets.UTF_8));
            try (FileInputStream fileInputStream = new FileInputStream(file)) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
            }
            outputStream.write(lineEnd.getBytes(StandardCharsets.UTF_8));
            outputStream.write((twoHyphens + boundary + twoHyphens + lineEnd).getBytes(StandardCharsets.UTF_8));
        }
        // Leer la respuesta
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            String line;
            StringBuilder response = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            // Parsear el JSON de la respuesta para obtener link
            String jsonResponse = response.toString();
            int linkStart = jsonResponse.indexOf("\"link\":\"") + 8;
            int linkEnd = jsonResponse.indexOf("\"", linkStart);
            if (linkStart == -1 || linkEnd == -1) {
                throw new Exception("Error al obtener el enlace de descarga.");
            }
            return jsonResponse.substring(linkStart, linkEnd);
        } catch (Exception e) {
            throw new Exception("Error al procesar la respuesta: " + e.getMessage());
        }
    }
    public String getLinkArchivo() {
        return linkArchivo; // Devuelve el enlace guardado
    }
    public void setLinkArchivo(String url){
        this.linkArchivo = url;
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButtonAdjuntos = new javax.swing.JButton();

        jButtonAdjuntos.setBackground(new java.awt.Color(221, 236, 238));
        jButtonAdjuntos.setFont(new java.awt.Font("Malgun Gothic", 1, 18)); // NOI18N
        jButtonAdjuntos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/componente/pngwing.com.png"))); // NOI18N
        jButtonAdjuntos.setText("Adjuntos");
        jButtonAdjuntos.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButtonAdjuntos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAdjuntosActionPerformed(evt);
            }
        });
        add(jButtonAdjuntos);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAdjuntosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAdjuntosActionPerformed
        
    }//GEN-LAST:event_jButtonAdjuntosActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAdjuntos;
    // End of variables declaration//GEN-END:variables
}
