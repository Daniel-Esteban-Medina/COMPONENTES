package componente;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.YearMonth;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
public class dias31 extends javax.swing.JPanel {
    LocalDate fechaActual = LocalDate.now();
    //Variables CALENDARIO
    private int mesNum = 1;
    private int ayo = 2024;
    private int dia = 1;    
    public dias31() {
        initComponents();
        // Ajustar la altura de las filas
        jTable1.setRowHeight(80);

        // Personalizar el renderizado del encabezado
        JTableHeader header = jTable1.getTableHeader();
        header.setPreferredSize(new Dimension(header.getWidth(), 30));
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                           boolean hasFocus, int row, int column) {
                JLabel label = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                label.setBackground(Color.RED);
                label.setForeground(Color.WHITE);
                label.setFont(label.getFont().deriveFont(Font.BOLD, 14f));
                label.setHorizontalAlignment(SwingConstants.CENTER);
                label.setOpaque(true);
                return label;
            }
        });
// Renderizar columnas
for (int i = 0; i < jTable1.getColumnCount(); i++) {
    jTable1.getColumnModel().getColumn(i).setCellRenderer(new TableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            JTextArea textArea = new JTextArea(value == null ? "" : value.toString());
            textArea.setLineWrap(true);
            textArea.setWrapStyleWord(true);
            textArea.setOpaque(true);
            textArea.setBorder(BorderFactory.createLineBorder(Color.RED, 1));

            if (isSelected) {
                textArea.setBackground(new Color(255,204,204));
                textArea.setForeground(Color.WHITE);
                textArea.setFont(new Font("Arial", Font.BOLD, 12));
            } else {
                textArea.setBackground(table.getBackground());
                textArea.setForeground(table.getForeground());
                textArea.setFont(new Font("Arial", Font.PLAIN, 12));
            }

            // Ajusta la altura de la fila si es necesario
            int textHeight = textArea.getPreferredSize().height;
            if (table.getRowHeight(row) < textHeight) {
                table.setRowHeight(row, textHeight);
            }

            if (value != null) {
                int diaCelda = 0;
                // Verifica si el valor es un Integer
                if (value instanceof Integer) {
                    diaCelda = (Integer) value;
                } else if (value instanceof String) {
                    try {
                        diaCelda = Integer.parseInt((String) value);
                    } catch (NumberFormatException e) {
                        // Si no es un número válido, dejamos la celda en blanco
                        textArea.setText("");  // Asigna texto vacío
                        return textArea;  // Retorna inmediatamente para evitar más cambios
                    }
                }

                // Si el día de la celda es el día actual
                if (diaCelda == fechaActual.getDayOfMonth() &&
                    fechaActual.getMonthValue() == mesNum &&
                    fechaActual.getYear() == ayo) {
                    textArea.setText(String.valueOf(diaCelda));
                    textArea.setBackground(new Color(255,173,131));  // Fondo naranja para el día actual
                    textArea.setBorder(BorderFactory.createLineBorder(new Color(253, 116, 37), 2));  // Borde rojo solo para el día actual
                } else {
                    textArea.setText(String.valueOf(diaCelda));
                    textArea.setBackground(table.getBackground()); // Fondo normal para otros días
                }
            } else {
                textArea.setText("");  // En caso de celdas vacías (fuera del mes)
                textArea.setBorder(null);  // Sin borde para celdas vacías
            }

            textArea.setOpaque(true); // Esto es necesario para que se muestren los colores de fondo
            return textArea;
        }
    });
}
    this.setFechaActual();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelAyo = new javax.swing.JLabel();
        jLabelMES = new javax.swing.JLabel();
        jButtonMenosAyo = new javax.swing.JButton();
        jButtonMenosMes = new javax.swing.JButton();
        jButtonMasMes = new javax.swing.JButton();
        jButtonMasAyo = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelAyo.setBackground(new java.awt.Color(249, 132, 132));
        jLabelAyo.setFont(new java.awt.Font("Dubai", 1, 22)); // NOI18N
        jLabelAyo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelAyo.setText("AÑO");
        jLabelAyo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabelAyo.setOpaque(true);
        add(jLabelAyo, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 40, 210, 69));

        jLabelMES.setBackground(new java.awt.Color(249, 132, 132));
        jLabelMES.setFont(new java.awt.Font("Dubai", 1, 22)); // NOI18N
        jLabelMES.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelMES.setText("MES");
        jLabelMES.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabelMES.setOpaque(true);
        add(jLabelMES, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, 670, 69));

        jButtonMenosAyo.setBackground(new java.awt.Color(249, 132, 132));
        jButtonMenosAyo.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButtonMenosAyo.setText("v");
        jButtonMenosAyo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButtonMenosAyo.setOpaque(true);
        jButtonMenosAyo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMenosAyoActionPerformed(evt);
            }
        });
        add(jButtonMenosAyo, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 76, 60, -1));

        jButtonMenosMes.setBackground(new java.awt.Color(249, 132, 132));
        jButtonMenosMes.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButtonMenosMes.setText("<");
        jButtonMenosMes.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButtonMenosMes.setOpaque(true);
        jButtonMenosMes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMenosMesActionPerformed(evt);
            }
        });
        add(jButtonMenosMes, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 50, 70));

        jButtonMasMes.setBackground(new java.awt.Color(249, 132, 132));
        jButtonMasMes.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButtonMasMes.setText(">");
        jButtonMasMes.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButtonMasMes.setOpaque(true);
        jButtonMasMes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMasMesActionPerformed(evt);
            }
        });
        add(jButtonMasMes, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 40, 50, 70));

        jButtonMasAyo.setBackground(new java.awt.Color(249, 132, 132));
        jButtonMasAyo.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButtonMasAyo.setText("^");
        jButtonMasAyo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButtonMasAyo.setOpaque(true);
        jButtonMasAyo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMasAyoActionPerformed(evt);
            }
        });
        add(jButtonMasAyo, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 40, 60, 40));

        jTable1.setBackground(new java.awt.Color(255, 204, 204));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "LUNES", "MARTES", "MIÉRCOLES", "JUEVES", "VIERNES", "SÁBADO", "DOMINGO"
            }
        ));
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable1);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 1040, 530));
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonMenosAyoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMenosAyoActionPerformed
        accionAyo(false);
    }//GEN-LAST:event_jButtonMenosAyoActionPerformed

    private void jButtonMenosMesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMenosMesActionPerformed
        accionMes(false);
    }//GEN-LAST:event_jButtonMenosMesActionPerformed

    private void jButtonMasMesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMasMesActionPerformed
        accionMes(true);
    }//GEN-LAST:event_jButtonMasMesActionPerformed

    private void jButtonMasAyoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMasAyoActionPerformed
        accionAyo(true);        
    }//GEN-LAST:event_jButtonMasAyoActionPerformed
    public void accionAyo(boolean accion){
        if(accion){
            ayo = ayo + 1;
        }else{
            ayo = ayo - 1;
        }
        this.actualizarTablaDias(ayo, mesNum);
    }
    public void accionMes(boolean accion){
        if(accion){
            mesNum = mesNum + 1;
        }else{
            mesNum = mesNum - 1;
        }
        if(mesNum > 12){
            mesNum = 1;
            ayo = ayo + 1;
        }
        if(mesNum < 1){
            mesNum = 12;
            ayo = ayo - 1;
        }
        this.actualizarTablaDias(ayo, mesNum);
    }
    // Método para actualizar los días en la tabla según mes y año
    public void actualizarTablaDias(int anyo, int mes) {
        // Obtener el modelo de la tabla y limpiar filas existentes
        DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel();
        modelo.setRowCount(0); // Limpiar las filas actuales

        // Obtener la fecha del primer día del mes y el número total de días del mes
        YearMonth yearMonth = YearMonth.of(anyo, mes);
        LocalDate primerDiaMes = yearMonth.atDay(1);
        int diasEnMes = yearMonth.lengthOfMonth();

        // Obtener el día de la semana del primer día del mes
        DayOfWeek primerDiaSemana = primerDiaMes.getDayOfWeek();
        int columnaInicio = primerDiaSemana.getValue() - 1; // Ajustar para que Lunes sea 0, Domingo sea 6

        // Llenar la tabla con los días del mes
        int dia = 1;
        int totalSemanas = (int) Math.ceil((diasEnMes + columnaInicio) / 7.0);

        for (int semana = 0; semana < totalSemanas; semana++) {
            Object[] diasSemana = new Object[7];
            for (int i = 0; i < 7; i++) {
                if (semana == 0 && i < columnaInicio || dia > diasEnMes) {
                    diasSemana[i] = "";  // Celdas vacías para días fuera del mes
                } else {
                    diasSemana[i] = dia;
                    dia++;
                }
            }
            modelo.addRow(diasSemana);
        }
        // Actualizar etiquetas de mes y año
        setNomMes(mes);
        jLabelAyo.setText(String.valueOf(anyo));
    }
    public void setFechaActual(){
        String[] partesFecha = fechaActual.toString().split("-");
        mesNum = Integer.parseInt(partesFecha[1]);
        ayo = Integer.parseInt(partesFecha[0]);
        dia = Integer.parseInt(partesFecha[2]);
        this.actualizarTablaDias(ayo, mesNum);
    }
    public void setNomMes(int mes){
    switch(mes){
            case 1:
                jLabelMES.setText("ENERO");
            break;
            case 2:
                jLabelMES.setText("FEBRERO");
            break;
            case 3:
                jLabelMES.setText("MARZO");
            break;
            case 4:
                jLabelMES.setText("ABRIL");
            break;
            case 5:
                jLabelMES.setText("MAYO");
            break;
            case 6:
                jLabelMES.setText("JUNIO");
            break;
            case 7:
                jLabelMES.setText("JULIO");
            break;
            case 8:
                jLabelMES.setText("AGOSTO");
            break;
            case 9:
                jLabelMES.setText("SEPTIEMBRE");
            break;
            case 10:
                jLabelMES.setText("OCTUBRE");
            break;
            case 11:
                jLabelMES.setText("NOVIEMBRE");
            break;
            case 12:
                jLabelMES.setText("DICIEMBRE");
            break;
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonMasAyo;
    private javax.swing.JButton jButtonMasMes;
    private javax.swing.JButton jButtonMenosAyo;
    private javax.swing.JButton jButtonMenosMes;
    private javax.swing.JLabel jLabelAyo;
    private javax.swing.JLabel jLabelMES;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
