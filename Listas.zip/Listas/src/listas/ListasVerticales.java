package listas;

import java.awt.List;
import java.util.HashMap;
import javax.swing.DefaultListModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class ListasVerticales extends javax.swing.JPanel {
    DefaultListModel<String> modeloVacia = new DefaultListModel<String>();
    DefaultListModel<String> modeloLlena = new DefaultListModel<String>();
    public ListasVerticales() {
        initComponents();
        jListVacia.setModel(modeloVacia);
        jListLlena.setModel(modeloLlena);
        jListLlena.addListSelectionListener(new ListSelectionListener() {

            @Override
            public void valueChanged(ListSelectionEvent arg0) {
                if (!arg0.getValueIsAdjusting()) {
                  String seleccion = jListLlena.getSelectedValue();
                  if (seleccion != null) {
                  modeloVacia.addElement(seleccion);                  
                  modeloLlena.removeElement(seleccion);
                  }
                }
            }
        });
        jListVacia.addListSelectionListener(new ListSelectionListener() {

            @Override
            public void valueChanged(ListSelectionEvent arg0) {
                if (!arg0.getValueIsAdjusting()) {
                  String seleccion = jListVacia.getSelectedValue();
                  if (seleccion != null) {
                  modeloLlena.addElement(seleccion);                  
                  modeloVacia.removeElement(seleccion);
                  }
                }
            }
        });
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jScrollPane1 = new javax.swing.JScrollPane();
        jListVacia = new javax.swing.JList<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        jListLlena = new javax.swing.JList<>();
        encabezadoListaLlena = new javax.swing.JLabel();
        encabezadoListaVacia = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setLayout(null);

        jListVacia.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane1.setViewportView(jListVacia);

        add(jScrollPane1);
        jScrollPane1.setBounds(0, 227, 167, 143);

        jListLlena.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(jListLlena);

        add(jScrollPane2);
        jScrollPane2.setBounds(0, 24, 169, 133);

        encabezadoListaLlena.setBackground(new java.awt.Color(192, 192, 192));
        encabezadoListaLlena.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        encabezadoListaLlena.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        encabezadoListaLlena.setText("LISTA LLENA");
        encabezadoListaLlena.setOpaque(true);
        add(encabezadoListaLlena);
        encabezadoListaLlena.setBounds(0, 0, 169, 24);

        encabezadoListaVacia.setBackground(new java.awt.Color(192, 192, 192));
        encabezadoListaVacia.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        encabezadoListaVacia.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        encabezadoListaVacia.setText("LISTA VACÍA");
        encabezadoListaVacia.setOpaque(true);
        add(encabezadoListaVacia);
        encabezadoListaVacia.setBounds(0, 203, 167, 24);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setText("^");
        add(jLabel3);
        jLabel3.setBounds(120, 160, 32, 40);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setText("v");
        add(jLabel5);
        jLabel5.setBounds(30, 160, 32, 40);
    }// </editor-fold>//GEN-END:initComponents
public void listaLlenarellenarListaEquipos(ResultSet rs){
    modeloLlena.clear();
    try{
        while(rs.next()){
            modeloLlena.addElement((String) rs.getObject("Nombre"));
        }
    }catch(SQLException e){
        System.out.println(e.toString());
    }                            
}
public void listaVaciaRellenarListaEquipos(ResultSet rs){
    modeloVacia.clear();
    try{
        while(rs.next()){
            modeloVacia.addElement((String) rs.getObject("Nombre"));
        }
    }catch(SQLException e){
        System.out.println(e.toString());
    }                            
}
public void listaLlenaRellenarListaPersonas(ResultSet rs){
    modeloLlena.clear();
    try{
        while(rs.next()){
            String elemento = (String) rs.getObject("Nombre")+" "+(String) rs.getObject("Apellidos");
            modeloLlena.addElement(elemento);
        }
    }catch(SQLException e){
        System.out.println(e.toString());
    }                            
}
public void listaVaciaRellenarListaPersonas(ResultSet rs){
    modeloVacia.clear();
    try{
        while(rs.next()){
            String elemento = (String) rs.getObject("Nombre")+" "+(String) rs.getObject("Apellidos");
            modeloVacia.addElement(elemento);
        }
    }catch(SQLException e){
        System.out.println(e.toString());
    }                            
}
public String[] getListaVaciaEquipos(){
    String[] resultado = null;
    for (int i = 0; i < modeloVacia.size(); i++) {
           resultado[i] = modeloVacia.getElementAt(i);
        }
    return resultado;
}
public String[] getListaVaciaPersonasNombre(){
    String[] resultado = null;
    for (int i = 0; i < modeloVacia.size(); i++) {
           String nombre = modeloVacia.getElementAt(i);
           String partes[] = nombre.split(" ");
           String nom = partes[0];
           resultado[i] = modeloVacia.getElementAt(i);
        }
    return resultado;
}
public String[] getListaVaciaPersonasApellidos(){
    String[] resultado = new String[modeloVacia.size()]; 
    for (int i = 0; i < modeloVacia.size(); i++) {
        String nombre = modeloVacia.getElementAt(i);
        String[] partes = nombre.split(" ");
        String nom = partes[1];
        resultado[i] = nom; 
    }
    return resultado;
}
public void setEncabezadoListaLlena(String texto){
    encabezadoListaLlena.setText(texto);
}
public void setEncabezadoListaVacia(String texto){
    encabezadoListaVacia.setText(texto);
}
public void limpiarjListVacia(){
    modeloVacia.clear();
}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel encabezadoListaLlena;
    private javax.swing.JLabel encabezadoListaVacia;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JList<String> jListLlena;
    private javax.swing.JList<String> jListVacia;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
