package pruebas;

import componente.Conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class VentanaPrueba2 extends javax.swing.JFrame {
    private Conexion conect = new Conexion();
    private Connection con = conect.getConexion();
    private Statement st;
    private ResultSet rs; 
    public VentanaPrueba2() throws SQLException {
        initComponents();
        listasVerticales1.setEncabezadoListaLlena("Coches");
        listasVerticales1.setEncabezadoListaVacia("Sonic");
        st = con.createStatement();
        rs = st.executeQuery("Select Nombre, Apellidos From Personas");
        listasVerticales1.listaLlenaRellenarListaPersonas(rs);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        listasVerticales1 = new listas.ListasVerticales();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.GridLayout());

        jButton1.setText("jButton1");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        getContentPane().add(listasVerticales1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String num[] = listasVerticales1.getListaVaciaPersonasApellidos();
        for(int i = 0; i < num.length; i++){
            System.out.println(num[i]+"\n");
        }
    }//GEN-LAST:event_jButton1ActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new VentanaPrueba2().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(VentanaPrueba2.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private listas.ListasVerticales listasVerticales1;
    // End of variables declaration//GEN-END:variables
}
