package pruebas;
import componente.Conexion;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class VentanaPrueba extends javax.swing.JFrame {
    private Conexion conect = new Conexion();
    private Connection con = conect.getConexion();
    private Statement st;
    private ResultSet rs;    
    
    public VentanaPrueba() throws SQLException {
        initComponents();
        listasHorizon2.setEncabezadoListaLlena("Coches");
        listasHorizon2.setEncabezadoListaVacia("Sonic");
        st = con.createStatement();
        /* Al rellenar la "lista llena" la consulta que hay que pasarle tiene que mostrar 
         todos los equipos de la base de datos, menos los equipos que estan asignados a esa tarea.
         EJ: SELECT E.Nombre FROM EQUIPOS E
             LEFT JOIN EQUIPOS_TAREAS ET ON E.Codigo = ET.Cod_equipo AND ET.Cod_tarea = <CODIGO_DE_LA_TAREA>
             WHERE ET.Cod_equipo IS NULL;
        
         Al rellenar la "lista vacía" la consulta que hay que pasarle tiene que mostrar 
         todos los equipos que estan asignados a esa tarea.
         EJ: SELECT E.Nombre FROM EQUIPOS E
             JOIN EQUIPOS_TAREAS ET ON E.Codigo = ET.Cod_equipo
             WHERE ET.Cod_tarea = <CODIGO_DE_LA_TAREA>;
        */
        rs = st.executeQuery("SELECT E.Nombre FROM EQUIPOS E\n" +
                            "LEFT JOIN EQUIPOS_TAREAS ET ON E.Codigo = ET.Cod_equipo AND ET.Cod_tarea = 12\n" +
                            "WHERE ET.Cod_equipo IS NULL ORDER BY E.Nombre ASC"); 
        listasHorizon2.listaLlenaRellenarListaEquipos(rs);
        rs = st.executeQuery("SELECT E.Nombre FROM EQUIPOS E\n" +
                            "JOIN EQUIPOS_TAREAS ET ON E.Codigo = ET.Cod_equipo\n" +
                            "WHERE ET.Cod_tarea = 12 ORDER BY E.Nombre ASC"); 
        listasHorizon2.listaVaciaRellenarListaEquipos(rs);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        listasHorizon2 = new listas.ListasHorizon();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.GridLayout());
        getContentPane().add(listasHorizon2);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new VentanaPrueba().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(VentanaPrueba.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private listas.ListasHorizon listasHorizon2;
    // End of variables declaration//GEN-END:variables
}
