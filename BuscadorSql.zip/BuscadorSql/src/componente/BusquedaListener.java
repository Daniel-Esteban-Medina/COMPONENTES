package componente;
public interface BusquedaListener {
    void actualizarBusqueda(String likeSql);
}
