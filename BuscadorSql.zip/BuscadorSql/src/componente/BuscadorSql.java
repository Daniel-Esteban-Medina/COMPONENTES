package componente;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
public class BuscadorSql extends javax.swing.JPanel {
    private String like = "";
    private BusquedaListener listener;
    // Constructor sin argumentos
    public BuscadorSql() {
        initComponents();
        jTextField1.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                getLikeSql();
            }
            @Override
            public void removeUpdate(DocumentEvent e) {
                getLikeSql();
            }
            @Override
            public void changedUpdate(DocumentEvent e) {
                getLikeSql();
            }
        });
    }
    // Constructor con argumento
    public BuscadorSql(BusquedaListener listener) {
        this();
        this.listener = listener;
    }
    public void setBusquedaListener(BusquedaListener listener) {
        this.listener = listener;
    }
    public String getLikeSql(){
        like = " LIKE '"+jTextField1.getText()+"%'";
        if (listener != null) {
            listener.actualizarBusqueda(like);
        }
        return like;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();

        setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.LINE_AXIS));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/componente/Zoom.png"))); // NOI18N
        jLabel1.setText("BUSCADOR ");
        add(jLabel1);

        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField1KeyPressed(evt);
            }
        });
        add(jTextField1);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField1KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1KeyPressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
